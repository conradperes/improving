package br.com.improving.backend;

public interface Webservice {
    void processed(String fileName);
}
