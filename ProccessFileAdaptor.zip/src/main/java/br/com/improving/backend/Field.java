package br.com.improving.backend;

public enum Field {
    DESCRIPTION,
    VALUE,
    TYPE;
}
