package br.com.improving.parser;

import br.com.improving.backend.Repository;
import br.com.improving.backend.Webservice;

public class Parser {
    private final Repository repository;
    private final Webservice webservice;

    public Parser(Repository repository, Webservice webservice) {
        this.repository = repository;
        this.webservice = webservice;
    }

    public void processFile(String filePath) {
        
    }
}
