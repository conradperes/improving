Nesta avaliação você deve criar um processador de arquivos. Você deve implementar o método processFile (classe br.com.improving.parser.Parser) que recebe o caminho completo para um arquivo que possui os seguintes campos: 

-descrição do cliente - deve ter entre 1 e 100 caracteres 
-valor monetário - com até 4 dígitos inteiros e sempre 2 decimais. Ex: 9999.99 
-tipo - pode ser C ou D.

Cada linha do arquivo representa um registro que precisa ser processado. Não existe cabeçalho com o nome dos campos. O conteúdo do arquivo é separado por TAB. O final da linha é representado por \n. Não há linhas em branco no arquivo e nem TAB depois do último campo. Veja um trecho de exemplo de um arquivo válido:

Machado de Assis 1899,99 D 
Clarice Lispector 387,00 C 
Drummond de Andrade 5667,87 C

 O processamento do arquivo consiste das seguintes etapas: Para gerar um arquivo válido para fins de testes utilize a classe GenerateFile disponibilizada no repositório. Há uma constante que define o tamanho do arquivo a ser gerado.

O processamento do arquivo consiste das seguintes etapas: 

1.	Registrar o nome do arquivo no banco de dados e obter seu identificador (id). Utilizar classe Repository usando para isso o método generateFileId.

2.	Validar cada registro do arquivo de acordo com a definição dos campos. Ou seja, verificar se a descrição tem o tamanho correto, se o valor monetário é válido e o tipo informado existe.

a.	Se o registro for inválido, registrar no banco de dados o id do arquivo, o número da linha (baseado em 1), o campo que foi considerado inválido e uma mensagem descritiva do problema encontrado - utilizar classe Repository usando para isso o método reportInvalidLine.

b.	Se o registro for válido, deve efetuar um lookup no banco de dados para recuperar o id do cliente, passando como parâmetro sua descrição - utilizar a classe Repository usando para isso o método getClientId.

i.	Se o lookup retornar null, o registro deve ser considerado inválido e deve ser seguido o fluxo definido no passo 2a. 

c.	Caso o lookup retorne um id diferente de nulo, deverá ser registrada no banco de dados o número da linha (iniciando a contagem de 1), código do cliente (recuperado no lookup prévio ao banco de dados) e o valor - utilizar classe Repository usando para isso o método save.

i.	Se o tipo for D, o valor deverá ser multiplicado por -1.

ii.	Se o tipo for C, o valor deve ser gravado da mesma forma que informado no arquivo.

3.	Ao término do processamento de todas as linhas do arquivo, deverá ser chamado o serviço passando o nome do arquivo processado - utilizar classe Webservice usando para isso o método processed.


Todos os métodos da classe Repository podem lançar exceções que sejam subclasses de RuntimeException a qualquer momento. Como o banco de dados e o webservice são comunicações externas, a comunicação pode repentinamente ficar lenta.